//
//  ScoresViewController.swift
//  Malipatlolla_WordPuzzle
//
//  Created by Malipatlolla,Harshavardhan Reddy on 2/12/17.
//  Copyright © 2017 Malipatlolla,Harshavardhan Reddy. All rights reserved.
//



    import UIKit
    
    class ScoresViewController: UIViewController {
        var lclvar1=supercls()
        
        override func viewDidLoad() {
            lclvar1 = (UIApplication.shared.delegate as! AppDelegate).cls
            super.viewDidLoad()

            // Do any additional setup after loading the view.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        @IBOutlet weak var count1: UILabel!
        
        @IBOutlet weak var count2: UILabel!
        
        override func viewDidAppear(_ animated: Bool) {
            count1.text!="\(lclvar1.palindromePercent*100)%"
            count2.text!="\(lclvar1.necklacePercent*100)%"
           
        }
        
        
        @IBAction func Reset(_ sender: Any) {
            count1.text="0%"
            count2.text="0%"
            lclvar1.succsesor = 0.0
            lclvar1.total = 0.0
            lclvar1.successor1 = 0.0
            lclvar1.total1 = 0.0
        }
        
}

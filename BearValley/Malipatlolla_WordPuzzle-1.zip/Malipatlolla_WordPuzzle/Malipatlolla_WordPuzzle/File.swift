//
//  File.swift
//  Malipatlolla_WordPuzzle
//
//  Created by Malipatlolla,Harshavardhan Reddy on 2/12/17.
//  Copyright © 2017 Malipatlolla,Harshavardhan Reddy. All rights reserved.
//

import Foundation



class supercls{
    
    
    
    
    
    var succsesor=0.0
    
    var total=0.0
    
    
    
    func checkPalindrome(input:String)->Bool
        
    {
        
        let inTxt=input
        
        if inTxt==String(input.characters.reversed())
            
        {
            
            return true
            
        }
            
        else{
            
            return false
            
        }
        
    }
    
    
    
    func checkingPal(inText:String, palUser:Bool)
        
    {
        
        total += 1
        
        if(palUser==checkPalindrome(input:inText))
            
        {
            
            succsesor += 1
            
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    var palindromePercent:Double{
        
        
        
        get{
            
            if total > 0.0
                
            {
                
                
                
                return succsesor/total
                
            }
                
            else{
                
                               
                
                
                return 0.0
                
            }
            
        }
        
        
        
    }
    
    var successor1=0.0
    
    var total1=0.0
    
    
    
    func Necklace(inNecklace:String) -> Bool
        
    {
        
        var neck=inNecklace
        
        
        
        let necklaceString = String(neck.characters.sorted())
        
        
        
        
        
        
        
        if necklaceString==neck
            
        {
            
            return true
            
        }
            
            
            
        else
            
        {
            
            return false
            
        }
        
        
        
        
        
    }
    
    
    
    func checkingNecklace(inText:String, neckUser:Bool)
        
    {
        
        print("entered")
        
        total1 += 1
        
        if(neckUser==Necklace(inNecklace:inText))
            
        {
            
            successor1 += 1
            
        }
        
    }
    
    
    
    
    
    
    
    var necklacePercent:Double{
        
        
        
        get{
            
                      print(total1)
            
            if total1 > 0.0
                
            {
                
                
                
                return successor1/total1
                
            }
                
            else{
                
                
                
                
                
                return 0.0
                
            }
            
        }
        
        
}
}

//
//  SecondViewController.swift
//  Malipatlolla_WordPuzzle
//
//  Created by Malipatlolla,Harshavardhan Reddy on 2/12/17.
//  Copyright © 2017 Malipatlolla,Harshavardhan Reddy. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
var lclvar3=supercls()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         lclvar3 = (UIApplication.shared.delegate as! AppDelegate).cls
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var Text2: UITextField!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func Yes2(_ sender: Any) {
        lclvar3.checkingNecklace(inText:Text2.text!, neckUser:true)

    }
   
    @IBAction func NO2(_ sender: Any) {
        lclvar3.checkingNecklace(inText:Text2.text!, neckUser:false)
    }
}


//
//  FirstViewController.swift
//  Malipatlolla_WordPuzzle
//
//  Created by Malipatlolla,Harshavardhan Reddy on 2/12/17.
//  Copyright © 2017 Malipatlolla,Harshavardhan Reddy. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    var lclvar2=supercls()
    
    override func viewDidLoad() {
        
        
        lclvar2 = (UIApplication.shared.delegate as! AppDelegate).cls
        super.viewDidLoad()
        
    }

    @IBOutlet weak var Text1: UITextField!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Yes1(_ sender: Any) {
        lclvar2.checkingPal(inText:Text1.text!, palUser:true)
    }

    @IBAction func NO1(_ sender: UIButton) {
    lclvar2.checkingPal(inText:Text1.text!, palUser:false)
    }
}


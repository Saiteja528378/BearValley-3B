//
//  model.swift
//  poke
//
//  Created by Jonnalagadda,Jaswanth Kumar on 4/5/17.
//  Copyright © 2017 Jonnalagadda,Jaswanth Kumar. All rights reserved.
//

import Foundation


class model
{
    var it:String
    
    init(it:String)
    {
        self.it = it
    }
    
}

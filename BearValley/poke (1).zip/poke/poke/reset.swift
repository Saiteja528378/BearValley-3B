//
//  reset.swift
//  poke
//
//  Created by Jonnalagadda,Jaswanth Kumar on 4/5/17.
//  Copyright © 2017 Jonnalagadda,Jaswanth Kumar. All rights reserved.
//

import UIKit

class reset: UIViewController {
    
    var local = model(it:" ")

    @IBOutlet weak var textview: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        local = (UIApplication.shared.delegate as! AppDelegate).glocal
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func red(_ sender: Any)
    {
    
        self.view.backgroundColor = UIColor.red
        
    }
    @IBAction func blue(_ sender: Any)
    {
        self.view.backgroundColor = UIColor.blue
    }
    
    
     @IBAction func reset(_ sender: Any)
     {
     
        self.view.backgroundColor = UIColor.white
        local.it = "  "
        textview.text = " "
    
        }
    
    override func viewWillAppear(_ animated: Bool)
    {
        textview.text = local.it
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

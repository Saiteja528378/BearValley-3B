//
//  SecViewController.swift
//  tableTest
//
//  Created by Jataprolu,Snigda on 4/6/17.
//  Copyright © 2017 Jataprolu,Snigda. All rights reserved.
//

import UIKit

class SecViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var labelText: UILabel!
    
var b="snigda"
    override func viewDidLoad() {
        super.viewDidLoad()
 
        labelText.text=b
        // Do any additional setup after loading the view.
    }

   
}

//
//  ViewController.swift
//  tableTest
//
//  Created by Jataprolu,Snigda on 4/6/17.
//  Copyright © 2017 Jataprolu,Snigda. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var a=["aa","bb","cd"]
    
    @IBOutlet weak var tableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate=self
        tableView.dataSource=self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return a.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell=UITableViewCell()
        print(indexPath.row)
        cell.textLabel?.text=a[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "first", sender: a[indexPath.row])
    }
    override func prepare(for segue: UIStoryboardSegue, sender:Any? ) {
        let c=segue.destination as! SecViewController
        c.b=sender as! String
    }
    
}






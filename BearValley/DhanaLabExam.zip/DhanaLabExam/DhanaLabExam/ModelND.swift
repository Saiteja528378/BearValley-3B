//
//  ModelND.swift
//  DhanaLabExam
//
//  Created by Dhanalakota,Neelesh Varma on 3/30/17.
//  Copyright © 2017 Dhanalakota,Neelesh Varma. All rights reserved.
//

import Foundation
class ModelND
{
    var buffer:String=""
}

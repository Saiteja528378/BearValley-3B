//
//  ViewController.swift
//  DhanaLabExam
//
//  Created by Dhanalakota,Neelesh Varma on 3/30/17.
//  Copyright © 2017 Dhanalakota,Neelesh Varma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var DhanaData:[String]=["Neelesh Varma", "Dhanalakota","a", "out","time"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let move=segue.destination as! DetailViewController
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell
        // cell = tableView.dequeueReusableCell(withIdentifier: "cast")!
        cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "NDcell")
        cell.textLabel?.text = DhanaData[indexPath.row]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DhanaData.count
    }


}

